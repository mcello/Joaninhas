#!/bin/bash

tar -vzcf mac0431-22014.tar.gz joaninhasCalorosas.c jcmake.sh Makefile createtar.sh

#chmod +x jcmake.sh createtar.sh

#tar -vzxf mac0431-22014.tar.gz
